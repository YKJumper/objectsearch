/**
 * @file FastKltTracker.h this is part of project 'vision'
 * Copyright © 2020-2024
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Created vitalii.nimych@gmail.com 16-03-2024
 */

#ifndef VISION_FASTKLTTRACKER_H
#define VISION_FASTKLTTRACKER_H
#include <opencv2/opencv.hpp>
#include <iostream>
#include <chrono>
#include <syslog.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>
#include <malloc.h>
#include "types_t.h"
#include "tracker.h"

class FastKltTracker {
public:
    FastKltTracker();
    void setParams(int maxPts = 300, cv::Size Grid = cv::Size(4, 5), int FastThreshold = 5, float shrinkRat = 0.2,
                   cv::Size KltWindowSize = cv::Size(11, 11), float RansacThreshold = 0.5);
    void init(const cv::Mat& frame, const cv::Rect& object);
    bool update(const cv::Mat& frame, cv::Rect2f& trackedObj, cv::Point2f center_point);
    bool reinit(void);
    int Distance(int x1, int x2, int y1, int y2);
    void UpdateStage();
    int AidReInitTracker;
    int ForceReinit;
    bool AidReInitOccured;
    tracker_stages_t ReinitStage;

private:
    cv::Rect2f findIntersection(const cv::Rect2f& input);
    cv::Rect shrinkRect(const cv::Rect& input);
    cv::Rect2f boundingRect2f(const std::vector<cv::Point2f>& points);
    void keepStrongest(int N, std::vector<cv::KeyPoint>& keypoints);
    std::vector<cv::Point2f> detectGridFASTpoints(cv::Mat image, cv::Rect object);
    float track(const cv::Mat& img_1, const cv::Mat& img_2, std::vector<cv::Point2f>& points1,
                std::vector<cv::Point2f>& points2);


    void set_init(bool);
    int maxTotalKeypoints;
    int FastThresh;
    cv::Size grid;
    cv::Size KltWinSize;
    float RansacThresh;
    std::vector<cv::Point2f> prevCorners;
    std::vector<cv::Point2f> prevKeypoints;
    cv::Mat prevGrayFrame;
    float shrinkRatio;
    bool ReInit;
};

#endif //VISION_FASTKLTTRACKER_H
