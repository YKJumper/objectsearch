#include "FastKltTracker.h"


int main() {
    // Open video file
    cv::VideoCapture cap("/home/dmytro/object_movement/120010.mkv");  // Use webcam for real-time tracking
    if (!cap.isOpened()) {
        std::cout << "Error opening video stream or file" << std::endl;
        return -1;
    }
    int maxFeatures = 100;
    int fastThreshold = 4;
    int nRows = 4;
    int nCols = 5;
    int kltWindowSize = 11; //TODO: Windows size for search next pixels
    float shrinkRatio = 0.1;
    float ransacThreshold = 0.9;
    cv::Mat frame;
    bool ret;
    ret = cap.read(frame);

    int i = 0;

    cv::Point point;

    // Read the first 1000 frames, converting each to grayscale
    while (i < 1000) {
        i++;
        ret = cap.read(frame);
        if (!ret) break;
        //cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);
    }

    FastKltTracker tracker;

    tracker.setParams(maxFeatures, cv::Size(nRows, nCols), fastThreshold, shrinkRatio,
                      cv::Size(kltWindowSize, kltWindowSize), ransacThreshold);

    cv::Rect tracked_area(frame.cols / 2 - 40, frame.rows / 2 - 40, 80, 80);
    tracker.init(frame, tracked_area);

    while (true) {
        ret = cap.read(frame);
        if (!ret) break;

        //cv::cvtColor(frame, frame, cv::COLOR_BGR2GRAY);

        cv::Rect2f trackedObj;

        int64 start_time = cv::getTickCount();
        bool status = tracker.update(frame, trackedObj, point);

        int64 end_time = cv::getTickCount();
        double elapsed_time = (end_time - start_time) / cv::getTickFrequency();

        // Print time taken per frame
        std::cout << "Time to process frame: " << elapsed_time << " seconds." << std::endl;

    }
}